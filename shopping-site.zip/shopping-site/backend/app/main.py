"""Entry point. Run from the backend folder:  uvicorn app.main:app --reload"""
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from app import models  # noqa: F401  (registers tables)
from app.core.config import FRONTEND_DIR
from app.core.database import Base, engine
from app.routers import admin, auth, cart, orders, products
from app.services.errors import ServiceError


@asynccontextmanager
async def lifespan(_: FastAPI):
    Base.metadata.create_all(bind=engine)
    yield


app = FastAPI(
    title="Haul Shop API",
    version="1.0.0",
    description="Shop backend. Every endpoint has a stable operation_id so it can be "
                "exposed to an LLM chatbot as a tool.",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten this to your real domain in production
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(ServiceError)
async def service_error_handler(_: Request, exc: ServiceError):
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.message})


for r in (auth.router, products.router, cart.router, orders.router, admin.router):
    app.include_router(r, prefix="/api")


@app.get("/api/health", tags=["Meta"], operation_id="health")
def health():
    return {"status": "ok"}


# Serve the HTML/CSS/JS frontend from the same server (mounted last).
app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")
